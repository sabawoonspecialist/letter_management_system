<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LettersController;
use App\Http\Controllers\Usercontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('login');
});
Route::view('dashboard','dashboard')->name('dashboard');

Route::get('incomming',[LettersController::class,'incomming'])->name('incomming');
Route::get('outgoing',[LettersController::class,'outgoing'])->name('outgoing');
Route::get('incomming_create',[LettersController::class,'incomming_create'])->name('incomming_create');

Route::get('user_create',[Usercontroller::class,'create'])->name('user_create');
Route::post('user_store',[Usercontroller::class,'store'])->name('user_store');
Route::post('user_login',[Usercontroller::class,'login'])->name('user_login');
