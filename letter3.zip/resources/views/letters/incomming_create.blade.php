<x-layout>
    
</x-layout>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <h1>Add Incomming Letter</h1>
    <form action="user_store" method="post">
        @csrf
  <div class="form-group">
    <label for="name">name</label>
    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Emplyee name">
  </div>
  <div class="form-group">
    <label for="username">Username</label>
    <input type="text" class="form-control" id="username" name="username" placeholder="Enter username">
  </div>
  <div class="form-group">
    <label for="password">Password</label>
    <input type="password" class="form-control" id="password" name="password" placeholder="Enter username">
  </div>
  <div class="form-group">
    <label for="type">Type</Select></label>
    <select class="form-control" id="type" name="type">
      <option value="user">user</option>
      <option value="admin">admin</option>
    </select>
  </div>

  <button type="submit" class="btn btn-primary">Save User</button>
</form>
    </main>

</body>
</html>