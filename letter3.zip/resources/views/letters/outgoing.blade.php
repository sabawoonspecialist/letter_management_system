<x-layout>
    
</x-layout>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <h1>Letters</h1>
    <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Source</th>
      <th scope="col">Destination</th>
      <th scope="col">date</th>
      <th scope="col">Content</th>
    </tr>
  </thead>
  <tbody>
    @php $count = 1 @endphp
    @foreach($letters as $letter)
    <tr>
      <th scope="row">{{$count}}</th>
      <td>{{$letter->source}}</td>
      <td>{{$letter->destination}}</td>
      <td>{{$letter->date}}</td>
      <td>{{$letter->content}}</td>
    </tr>
    @php $count += 1 @endphp
    @endforeach
  </tbody>
</table>
</main>

</body>
</html>