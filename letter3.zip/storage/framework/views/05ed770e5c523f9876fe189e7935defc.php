<div>
    <h1><?php echo e($title); ?></h1>
    <!-- Knowing is not enough; we must apply. Being willing is not enough; we must do. - Leonardo da Vinci -->
</div><?php /**PATH C:\xampp\htdocs\mywebsite\resources\views/components/header.blade.php ENDPATH**/ ?>