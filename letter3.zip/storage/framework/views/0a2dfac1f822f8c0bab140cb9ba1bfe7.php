<div>
    <label style="display:block"><?php echo e($label); ?></label>
    <input type="<?php echo e($type); ?>" style="width:300px;height:30px;margin:12px;" placeholder="<?php echo e($holder); ?>" value="<?php echo e($demo); ?>">
</div><?php /**PATH C:\xampp\htdocs\mywebsite\resources\views/components/input.blade.php ENDPATH**/ ?>