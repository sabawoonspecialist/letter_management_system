<html>
    <head>
        <title>welcome to laravel </title>
    </head>
    <body>
        <h1>Welcome page....</h1>
    </bdoy>
</html><?php /**PATH C:\xampp\htdocs\mywebsite\resources\views/welcome.blade.php ENDPATH**/ ?>