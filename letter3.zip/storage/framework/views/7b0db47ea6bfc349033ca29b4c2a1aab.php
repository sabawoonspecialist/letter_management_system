<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <h1>Add Incomming Letter</h1>
    <form action="user_store" method="post">
        <?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="name">name</label>
    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Emplyee name">
  </div>
  <div class="form-group">
    <label for="username">Username</label>
    <input type="text" class="form-control" id="username" name="username" placeholder="Enter username">
  </div>
  <div class="form-group">
    <label for="password">Password</label>
    <input type="password" class="form-control" id="password" name="password" placeholder="Enter username">
  </div>
  <div class="form-group">
    <label for="type">Type</Select></label>
    <select class="form-control" id="type" name="type">
      <option value="user">user</option>
      <option value="admin">admin</option>
    </select>
  </div>

  <button type="submit" class="btn btn-primary">Save User</button>
</form>
    </main>

</body>
</html><?php /**PATH C:\xampp\htdocs\mywebsite\resources\views/letters/incomming_create.blade.php ENDPATH**/ ?>