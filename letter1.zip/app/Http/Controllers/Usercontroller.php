<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Department;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class Usercontroller extends Controller
{
    public function create(){
        $departments = Department::all();
        return view('users.create',compact('departments'));
    }
    public function store(Request $request){
        $name = $request->name;
        $username = $request->username;
        $password = Hash::make($request->password);
        $type = $request->type;
        $department = $request->department;

        $user =new User;
        $user->name = $name;
        $user->username = $username;
        $user->password = $password;
        $user->type = $type;
        $user->department_id = $department;
        $user->save();
       return back();
    }
    public function login(Request $request){
        $this->validate($request, [
            'username' => 'required|string',
            'password' => 'required|string',
        ]);
    
        $check = User::where('username', $request->username)
                      ->get()
                      ->filter(function ($user) use ($request) {
                          return Hash::check($request->password, $user->password);
                      });
    // return $check;
        if($check->isEmpty()){
            return redirect()->route('/');
        }
        else{
            return redirect()->route('dashboard');
        }
    }

}
