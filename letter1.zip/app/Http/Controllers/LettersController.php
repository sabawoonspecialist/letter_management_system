<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Letter;

class LettersController extends Controller
{
    public function incomming(){
        $letters = Letter::where('type','incomming');
        return view('letters.incomming',compact('letters'));
    }
    public function outgoing(){
        $letters = Letter::where('type','outgoing');
        return view('letters.outgoing',compact('letters'));
    }
    public function incomming_create(){
        return view('letters.incomming_create');
    }
}
